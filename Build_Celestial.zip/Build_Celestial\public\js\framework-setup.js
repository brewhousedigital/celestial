// Could be useful.
const body = document.querySelector("body");


// This is used for the API. It replaces your button text temporarily to let the user know something is happening
// You could use the text "loading..."
// or "🔥" which is a cool fire emoji. Could use any emoji, really. Who really cares about UX, amirite?
// or something like font awesome "<i class='fas fa-spinner'></i>"
const loadingText = "🔥";





