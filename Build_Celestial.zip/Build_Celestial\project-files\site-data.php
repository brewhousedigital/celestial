<?php


// Custom variables go here
// $data['site']['variable-name-here'] = "site wide";
// $data['page']['variable-name-here'] = "page specific stuff";
// $data['user']['variable-name-here'] = "user information";
